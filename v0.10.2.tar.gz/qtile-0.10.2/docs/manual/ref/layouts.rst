================
Built-in Layouts
================

.. qtile_class:: libqtile.layout.floating.Floating
    :no-commands:

.. qtile_class:: libqtile.layout.matrix.Matrix
    :no-commands:

.. qtile_class:: libqtile.layout.max.Max
    :no-commands:

.. qtile_class:: libqtile.layout.xmonad.MonadTall
    :no-commands:

.. qtile_class:: libqtile.layout.ratiotile.RatioTile
    :no-commands:

.. qtile_class:: libqtile.layout.slice.Slice
    :no-commands:

.. qtile_class:: libqtile.layout.stack.Stack
    :no-commands:

.. qtile_class:: libqtile.layout.tile.Tile
    :no-commands:

.. qtile_class:: libqtile.layout.tree.TreeTab
    :no-commands:

.. qtile_class:: libqtile.layout.verticaltile.VerticalTile
    :no-commands:

.. qtile_class:: libqtile.layout.zoomy.Zoomy
    :no-commands:
