==============
Built-in Hooks
==============

.. qtile_hooks:: libqtile.hook.subscribe
