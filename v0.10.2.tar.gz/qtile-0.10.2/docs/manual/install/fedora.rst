====================
Installing on Fedora
====================

Stable versions of Qtile are currently packaged for current versions of Fedora.
To install this package, run:

.. code-block:: bash

    dnf -y install qtile
